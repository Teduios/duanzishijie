//
//  MenuListModel.m
//  BaseProject
//
//  Created by ios on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MenuListModel.h"

@implementation MenuListModel
+(NSDictionary *)objectClassInArray{
    return @{@"result":[MenuListResultModel class]};
}
@end
@implementation MenuListPagingModel



@end
@implementation MenuListResultModel



@end