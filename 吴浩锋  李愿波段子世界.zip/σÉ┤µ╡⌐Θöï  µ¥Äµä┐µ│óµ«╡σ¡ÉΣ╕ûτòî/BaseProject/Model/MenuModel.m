//
//  MenuModel.m
//  BaseProject
//
//  Created by ios on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MenuModel.h"

@implementation MenuModel
+(NSDictionary*)objectClassInArray{
    return @{@"links":[MenuLinksModel class]};

}
@end
@implementation MenuLinksModel


@end