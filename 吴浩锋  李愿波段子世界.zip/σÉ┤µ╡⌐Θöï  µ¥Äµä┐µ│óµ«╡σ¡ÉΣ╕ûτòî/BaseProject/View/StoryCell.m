//
//  StoryCell.m
//  BaseProject
//
//  Created by ios on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "StoryCell.h"

@implementation StoryCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
