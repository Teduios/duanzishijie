//
//  StoryDetailViewController.h
//  BaseProject
//
//  Created by ios on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StoryDetailViewController : UIViewController
@property(nonatomic,strong)NSURL *shareUrl;
@end
