//
//  GameTabBarController.h
//  BaseProject
//
//  Created by ios on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TuWanListTableController.h"
@interface GameTabBarController : UITabBarController
+(GameTabBarController*)standardInstance;
@end
